'''
Project Name: Data Project
Name: Tristan Beuman and Karl Agustin
Class Period: AP CSP / 3
'''
#imports
import matplotlib.pyplot as plt
import os

def piechart():
    categories = []
    datas = []
    
    colortypes = ['green', 'cyan', 'lime', 'gray', 'red', 'white', 'yellow']
    directory = os.path.dirname(os.path.abspath(__file__)) #looks for the directory folder
    filename = os.path.join(directory, 'dataone.txt') 
    datafile = open(filename,'r') #opens that data file "dataone.txt"

    for line in datafile:
        job, data = line.split(',')
        categories += [job] #inputs the name of the data into the categories list in line 11
        datas += [data] #inputs the numbers/data into the data list on line 12
    fig, ax = plt.subplots(1, 1) 
    ax.pie(datas, labels=categories, colors=colortypes, autopct= '%.0f%%') #Creates the pie chart
    ax.set_aspect(1)
    ax.set_title('US National Debt for 2015') #Sets the pie chart title as "National Debt 2015"
    fig.show()

#Link to data: https://www.treasurydirect.gov/govt/reports/pd/mspd/2015/2015_jan.htm